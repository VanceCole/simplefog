/*
 * Global SimpleFog Configuration Options
 */

export default [
  {
  },
];

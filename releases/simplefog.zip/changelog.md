## 0.1.1
* Fixes a compatibility issue with various modules that affect the layer stack

## 0.1.0
* Initial release